<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\sigesc-site\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>